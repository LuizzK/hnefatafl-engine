# Test package for Copenhagen Hnefatafl
