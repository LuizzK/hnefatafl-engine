"""
Copenhagen Hnefatafl Engine
An AlphaZero-style engine for Copenhagen Hnefatafl using self-play reinforcement learning.
"""

__version__ = "0.1.0"
